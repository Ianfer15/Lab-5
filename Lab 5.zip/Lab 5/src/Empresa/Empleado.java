package Empresa;

public class Empleado {
    private String cedula;
    private String nombre;
    private String departamento;
    private double salarioBruto;
    private double descuentoAdicional;

    public Empleado(String cedula, String nombre, String departamento, double salarioBruto, double descuentoAdicional) {
        this.cedula = cedula;
        this.nombre = nombre;
        this.departamento = departamento;
        this.salarioBruto = salarioBruto;
        this.descuentoAdicional = descuentoAdicional;
    }

    public double calcularSeguroSocial() {
        return salarioBruto * 0.0975;
    }

    public double calcularSeguroEducativo() {
        return salarioBruto * 0.0125;
    }

    public double calcularSalarioNeto() {
        return salarioBruto - calcularSeguroSocial() - calcularSeguroEducativo() - descuentoAdicional;
    }

    public void imprimirEncabezado() {
        System.out.printf("%-15s %-15s %-15s %-15s %-15s %-20s %-20s %-15s%n",
                "Cédula", "Nombre", "Departamento", "Bruto", "S. Social", "S. Educativo", "Descuento Adicional", "Neto");
    }

    public void imprimirInformacion() {
        System.out.printf("%-15s %-15s %-15s %-15.2f %-15.2f %-20.2f %-20.2f %-15.2f%n",
                cedula, nombre, departamento, salarioBruto, calcularSeguroSocial(),
                calcularSeguroEducativo(), descuentoAdicional, calcularSalarioNeto());
    }
}
